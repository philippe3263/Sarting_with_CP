/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carre_magique;

import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solution;
import org.chocosolver.solver.variables.IntVar;

        

public class Carre_magique {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // 1. Declaration du modèle
        
        int n=4;
        Model mon_modele = new Model("Carre magique");                      
         
        // 2. variables
        IntVar[] vars = new IntVar[n*n] ;
        for (int i=0 ; i<n ; i++){
          for (int j=0 ; j<n ; j++){
            vars[i*n+j] = mon_modele.intVar("C_"+i+ "_"+j, 1, n*n); }
        }

        IntVar somme = mon_modele.intVar("somme",n*(n*n+1)/2);
   
        // contrainte 2
        for (int i=0; i<n*n; i++){
           for (int j=0; j<i; j++){
              mon_modele.arithm(vars[i], "!=",vars[j]).post();
           }
        }     
        


        
        // contrainte 3-4
        
        int[] coeffs = new int[n];
        for (int i = 0; i < n; i++) 
        {
          coeffs[i] = 1;
        }
    
        for (int i=0; i<n; i++)
        {
           IntVar[] colonne = new IntVar[n]; 
           IntVar[] ligne = new IntVar[n]; 
            
           for (int j=0; j<n; j++)
           {
              colonne[j] = vars[i*n+j];
              ligne[j] = vars[j*n+i];
           }

          mon_modele.scalar(colonne, coeffs,"=",somme).post();
          mon_modele.scalar(ligne, coeffs,"=",somme).post();
        }     
        
        // contrainte 5 : diagonale numero 1
        

      // int[] coeffs = new int[n];
        for (int i = 0; i < n; i++) 
        {
                coeffs[i] = 1; 
        }

        IntVar[] ligne = new IntVar[n]; 
        for (int i=0; i<n; i++)
        {
         ligne[i] = vars[i*n+i];
        }
        mon_modele.scalar(ligne, coeffs,"=",somme).post();


        // contrainte 6 : diagonale numero 2
    
        for (int i = 0; i < n; i++) 
        {
                coeffs[i] = 1; 
        }

        
        for (int i=0; i<n; i++)
        {
         ligne[i] = vars[(n-i)*n-(n-i)];
        }
        mon_modele.scalar(ligne, coeffs,"=",somme).post();


              
        
        //--------------------------------------------------------------------//
        
        System.out.println(mon_modele.toString());
        Solution solution = mon_modele.getSolver().findSolution();
        if(solution != null)
	{
         System.out.println(solution.toString());
        }         
        else
            System.out.println("pas de solution");

    }
    

    
    
}

