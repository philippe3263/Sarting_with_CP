#include <ctime>
#include <string.h>
#include <iostream>
#include <ilcplex/ilocplex.h>  
#include <ilcp\cp.h>


ILOSTLBEGIN

using namespace std;
const double EPS = 10e-6;

int main(int argc, char **argv)
{
	const char* Names[] = { "blue", "white", "yellow", "green" };

	try {

		IloEnv env;
		IloModel model(env, "Demonstration");

		IloIntVar Belgium(env, 0, 3, "B");
		IloIntVar Denmark(env, 0, 3, "DK");
		IloIntVar France(env, 0, 3, "F");
		IloIntVar Germany(env, 0, 3, "D");
		IloIntVar Luxembourg(env, 0, 3, "L");
		IloIntVar Netherlands(env, 0, 3, "NE");

		model.add(Belgium != France);
		model.add(Belgium != Germany);
		model.add(Belgium != Netherlands);
		model.add(Belgium != Luxembourg);
		model.add(Denmark != Germany);
		model.add(France != Germany);
		model.add(France != Luxembourg);
		model.add(Germany != Luxembourg);
		model.add(Germany != Netherlands);

		IloCP cp(model);

		if (cp.solve())
		{
			cout << std::endl << cp.getStatus() << " Solution" << std::endl;
			cout << "Belgium: " << Names[cp.getValue(Belgium)] << std::endl;
			cout << "Denmark: " << Names[cp.getValue(Denmark)] << std::endl;
			cout << "France:  " << Names[cp.getValue(France)] << std::endl;
			cout << "Germany: " << Names[cp.getValue(Germany)] << std::endl;
			cout << "Luxembourg: " << Names[cp.getValue(Luxembourg)] << std::endl;
			cout << "Netherlands:" << Names[cp.getValue(Netherlands)] << std::endl;
		}
	}
	catch (IloException& e) {
		cerr << "Concert exception caught: " << e << endl;
	}
}
